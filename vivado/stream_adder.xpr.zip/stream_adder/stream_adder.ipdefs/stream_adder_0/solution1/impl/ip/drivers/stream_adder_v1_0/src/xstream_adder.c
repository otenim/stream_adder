// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xstream_adder.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XStream_adder_CfgInitialize(XStream_adder *InstancePtr, XStream_adder_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilites_BaseAddress = ConfigPtr->Axilites_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XStream_adder_Set_mult_V(XStream_adder *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_adder_WriteReg(InstancePtr->Axilites_BaseAddress, XSTREAM_ADDER_AXILITES_ADDR_MULT_V_DATA, (u32)(Data));
    XStream_adder_WriteReg(InstancePtr->Axilites_BaseAddress, XSTREAM_ADDER_AXILITES_ADDR_MULT_V_DATA + 4, (u32)(Data >> 32));
}

u64 XStream_adder_Get_mult_V(XStream_adder *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_adder_ReadReg(InstancePtr->Axilites_BaseAddress, XSTREAM_ADDER_AXILITES_ADDR_MULT_V_DATA);
    Data += (u64)XStream_adder_ReadReg(InstancePtr->Axilites_BaseAddress, XSTREAM_ADDER_AXILITES_ADDR_MULT_V_DATA + 4) << 32;
    return Data;
}

